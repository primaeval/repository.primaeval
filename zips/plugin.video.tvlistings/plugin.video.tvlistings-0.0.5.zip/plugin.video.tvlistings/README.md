# plugin.video.tvlistings

# TV Listings

UK TV Listings with catchup playback via Meta4Kodi and live playback via addons.

* Favourite Channels
* Now/Next/After
* Channel Listings

## Notes
* Creates template.ini and myaddons.ini files with channel names on first run in userdata\addon_data\plugin.video.tvlistings directory.
* Favourites: Toggle has strange behaviour. On Windows it goes back to the top of the list. On Android it does not refresh on toggle.
* Force channel and ini file reload in the Settings if you chage addons.ini or myaddons.ini.

## Disclaimer
* Acts as a front end to tvguide.co.uk. It is not a product or endorsed addon of tvguide.co.uk.
