# plugin.video.tvlistings.xmltv

# TV Listings (json)

xmltv TV Listings with catchup playback via Meta4Kodi and live playback via addons.

* Now/Next/After
* Channel Listings
* Programme Search

## Notes
* Run the xmltv.create.db.py script on your server after you create your xmltv.xml file.
* Run the xmltv.server.py script to launch the json server on your server.
* Try using WebGrab++ to make smaller xmltv files.
* I recommend using Super Favourites to organise your favourite channels.
* Force ini file reload in the Settings if you change addons.ini or myaddons.ini.

## Disclaimer

