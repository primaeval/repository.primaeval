# plugin.video.tvlistings.xml2bsv

# TV Listings (xml2bsv)

xml2bsv TV Listings with catchup playback via Meta4Kodi and live playback via addons.

* Now/Next/After
* Channel Listings

## Notes
* Run xml2bsv.py on server after creating xmltv.xml file.
* Try using WebGrab++ to make smaller xmltv files.
* I recommend using Super Favourites to organise your favourite channels.
* Force ini file reload in the Settings if you change addons.ini or myaddons.ini.
* bsv files should reload on a folder modification difference. They can be forced too.

## Disclaimer

