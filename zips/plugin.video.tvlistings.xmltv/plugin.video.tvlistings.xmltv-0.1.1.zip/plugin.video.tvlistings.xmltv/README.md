# plugin.video.tvlistings.xmltv

# TV Listings (xmltv)

xmltv TV Listings with catchup playback via Meta4Kodi and live playback via addons.

* Now/Next/After
* Channel Listings
* Programme Search
* Watch/Remind Timers

## Usage
* Choose an xmltv file or url
* Use the Addon Browser to add a folder of TV channel shortcuts.
* Automatically remap channels via Addon Shortcuts.
* Some addon shortcuts need the alternative play method.

## Notes
* Try using WebGrab++ to create smaller xmltv files.

## Disclaimer

