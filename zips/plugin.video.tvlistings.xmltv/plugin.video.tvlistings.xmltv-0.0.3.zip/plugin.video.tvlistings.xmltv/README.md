# plugin.video.tvlistings.xmltv

# TV Listings (xmltv)

xmltv TV Listings with catchup playback via Meta4Kodi and live playback via addons.

* Now/Next/After
* Channel Listings

## Notes
* Huge xmltv files will take forever and may run out of memory.
* Try using WebGrab++ to make smaller xmltv files.
* I recommend using Super Favourites to organise your favourite channels.
* Force ini file reload in the Settings if you change addons.ini or myaddons.ini.
* xmltv file should reload on a file modification difference. It can be forced too.

## Disclaimer

