import xbmc

xbmc.executebuiltin("RunPlugin(plugin://plugin.video.replay/record_last)")
