# skin.naked
minimal kodi skin for phones

Just enough info to play videos and music on a teeny tiny mobile phone screen.

Big fonts and buttons (relatively).

No animations or eye candy.

