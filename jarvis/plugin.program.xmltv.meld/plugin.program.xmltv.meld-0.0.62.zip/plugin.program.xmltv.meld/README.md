# xmltv Meld

## plugin.program.xmltv.meld

* Joins xmltv providers into one xmltv file.
* Current sources are from rytec, zap, koditvepg.

# Quick Start
* Download busybox for your device. 
* Busybox: https://www.busybox.net/ 
* Windows: https://frippery.org/busybox/ 
* Android: https://github.com/Gnurou/busybox-android
* Point to busybox in Settings.
* Android will copy busybox to /data/data/ to be runnable.
* Change your zap zipcode.
* Select some providers (right click Add xmltv/zap).
* Select some channels (click to add, right click to remove).
* Press Update to generate an xmltv.xml and channels.m3u8 files in addon_data/plugin.program.xmltv.meld
* Turn the Service on and set a time or period to update the xmltv file.
