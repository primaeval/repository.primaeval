# script.games.play.mame
insert coin. press play.
