# plugin.video.tvlistings.yo

# TV Listings (yo.tv)

yo.tv Listings with catchup playback via Meta4Kodi and live playback via addons.

Covers 54 countries (not currently working: US, France, Germany)

* Favourite Channels
* Now/Next/After
* Channel Listings

## Notes
* Setting to create template [country].ini and myaddons.ini files with channel names in userdata\addon_data\plugin.video.tvlistings.yo directory.
* I recommend using Super Favourites to organise your favourite channels.
* Force ini file reload in the Settings if you change addons.ini or myaddons.ini.

## Disclaimer
* Acts as a front end to yo.tv. It is not a product or endorsed addon of yo.tv.
